from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import settings
from selenium import common

from mypkg.page_load import wait_for_page_load

browser = webdriver.Chrome()
browser.get("https://www.google.com")
element = browser.find_element_by_name("q")
my_page = browser.find_element_by_tag_name("html")
print my_page.id
element.send_keys("stackoverflow")
browser.find_element_by_name("btnK").click()
'''Approach 1'''
elemd=None
while True:
    try:
        elemd = browser.find_element_by_xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/h3/a")
        print "hello found it",elemd.id
        break
    except NoSuchElementException:
        print "Page has not been loaded yet, retrying to find the elem.."



'''Appoach 2'''
#
# my_page2 = browser.find_element_by_tag_name("html")
# while my_page2.id == my_page.id:
#     my_page2 = browser.find_element_by_tag_name("html")
#     print my_page2.id,my_page.id


# elem1 = browser.find_element_by_xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/h3/a")
# elem1.click()
# browser.close()


# with wait_for_page_load(browser):
#     browser.find_element_by_xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/h3/a").click()