import os

os.environ['PATH']=os.environ['PATH']+':'+'/home/c14795/WiSTA/WNMC/jars/chrmdrv'
print os.environ['PATH']
