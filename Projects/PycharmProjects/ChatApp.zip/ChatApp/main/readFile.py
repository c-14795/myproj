import  json

data={}
with open('data.json') as f:
    data = json.load(f)