from main import app
app.run('0.0.0.0', 8976, debug=True, threaded=True)