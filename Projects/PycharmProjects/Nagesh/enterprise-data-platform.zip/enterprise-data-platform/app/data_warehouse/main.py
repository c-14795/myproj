from app.data_warehouse.mobile_device_pipeline import MobileDevice

pipelines = {
    "MOBILE_DEVICE": MobileDevice,
}
