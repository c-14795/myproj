# from app.common.utils.app_logger import initialize_logging,get_logger
# import logging
# from datetime import datetime
#
# import sys
# print(sys.argv)
# initialize_logging(app_name="test", local_log_path="/home/c14795/PycharmProjects/Nagesh/EnterpriseData-Platform/app/",
#                    log_file_name='-'.join(["appName",str(datetime.now().date())]), log_level=logging.DEBUG)
# log = logging.getLogger("State")
# log_e = logging.getLogger("Execution")
# log.debug("hey log is working fine")
# log_e.debug("hey log is working fine")


# import logging
# logging.basicConfig(level=logging.INFO)
# log = logging.getLogger("test")
# log.info("hellooo")







