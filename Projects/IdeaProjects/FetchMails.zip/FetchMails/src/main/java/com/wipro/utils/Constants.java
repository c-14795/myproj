package com.wipro.utils;

import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Constants {

    private static  final String dateSep = "-";
    private static final String dateFormat = "dd" + dateSep + "MM" + dateSep + "yyyy";
    public static final DateFormat   formatter = new SimpleDateFormat(dateFormat);
    public  static  final String[] headers  = new String[]{"SenderName","SenderEmailID","Body","Subject","DateTimeReceived"};
    private static final  String path = Props.PropertiesFile().getProperty("OUTPUT_FILE","output.csv");
    public static  final CsvWriter writer = new CsvWriter(new File(path), new CsvWriterSettings());




}


