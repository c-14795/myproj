package com.wipro.fetchmails;

import com.wipro.utils.Constants;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.BodyType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.SortDirection;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.FolderView;
import microsoft.exchange.webservices.data.search.ItemView;


import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.regex.Pattern;

import com.wipro.utils.Props;


 class Mail {

    private ExchangeService service = null;
    private FolderId folderId = null;
    private final Properties properties = Props.PropertiesFile();
    private final String senders = properties.getProperty("SENDER_LIST", "None");
    private final List<String> senders_list = Objects.equals(senders, "None") ? new ArrayList<>() : Arrays.asList(senders.split(Pattern.quote(";")));

    Mail() throws Exception {
        setService();
        setFolderId();
    }

    private void setService() throws URISyntaxException {

        service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
        ExchangeCredentials credentials = new WebCredentials(properties.getProperty("USER_NAME"), properties.getProperty("PSWD"));
        service.setCredentials(credentials);
        URI url = new URI(properties.getProperty("URL"));
        service.setUrl(url);

    }

    private void setFolderId() throws Exception {
        ArrayList<Folder> folders = service.findFolders(WellKnownFolderName.MsgFolderRoot, new FolderView(100)).getFolders();
        for (Folder f : folders) {
            ///System.out.println(f.getDisplayName());
            if (properties.getProperty("FOLDER_NAME").equals(f.getDisplayName())) {
                //System.out.println("I am here");
                folderId = f.getId();
                // System.out.println("Success");
                //System.out.println(folder_id.toString());
                // System.out.println("Success");
                break;
            }
        }

    }

     void fetchData() throws Exception {

        Folder inbox = Folder.bind(service, folderId == null ? new FolderId(WellKnownFolderName.Inbox) : folderId);
        ItemView view = new ItemView(100);
        view.getOrderBy().add(ItemSchema.DateTimeReceived, SortDirection.Descending);
        FindItemsResults<Item> findResults;

        Date start_date = Constants.formatter.parse(properties.getProperty("START_DATE"));
        Date end_date = Constants.formatter.parse(properties.getProperty("END_DATE"));
        PropertySet prpSet = new PropertySet(BasePropertySet.FirstClassProperties);
        prpSet.setRequestedBodyType(BodyType.Text);
         System.out.println("S");
        my_loop:do {

            findResults = service.findItems(inbox.getId(), view);
            for (Item item : findResults.getItems()) {
                if(item.getDateTimeReceived().before(end_date) && item.getDateTimeReceived().after(start_date)) {
                    String sender_address = ((EmailMessage) item).getFrom().getAddress();
                    if (senders_list.contains(sender_address)) {
                        item.load(prpSet);
                        System.out.println(item.getSubject());
                        System.out.println(item.getDateTimeReceived());
                        System.out.println(item.getBody());
                        System.out.println(sender_address);
                        Main.mailData.add(new String[]{((EmailMessage) item).getSender().getName(),sender_address,item.getBody().toString(),item.getSubject(),item.getDateTimeReceived().toString()});
                    }
                }
                else if(item.getDateTimeReceived().before(start_date))
                {
                    break my_loop;
                }
            }
            view.setOffset(view.getOffset() + 100);
        } while (findResults.isMoreAvailable());

    }


}
