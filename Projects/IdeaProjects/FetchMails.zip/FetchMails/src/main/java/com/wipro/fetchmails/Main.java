package com.wipro.fetchmails;

import java.util.ArrayList;

import static com.wipro.utils.Constants.headers;
import static com.wipro.utils.Constants.writer;

public class Main {
    static ArrayList<String[]> mailData = new ArrayList<>();

    public static void main(String[] args) {

        try {
            writer.writeHeaders(headers);
            new Mail().fetchData();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            for (String[] row : mailData) {
                writer.writeRow(row);
            }
            writer.close();
        }
    }
}
