package com.wipro.utils;

final class LogInit {


}
